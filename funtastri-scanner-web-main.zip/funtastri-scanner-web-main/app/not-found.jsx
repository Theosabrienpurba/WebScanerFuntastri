import Link from "next/link"

const NotFound = () => {
  return (
    <div className="px-4 pt-8 text-center">
      <p className="font-medium">404 - Not Found</p>
      <h2 className="text-lg font-semibold my-3">Maaf~ Halaman tidak dapat ditemukan</h2>
      <p className="mb-2">Halaman mungkin sudah dipindah atau dihapus</p>
      <p className="mb-2">Pastikan bahwa link benar</p>

      <Link href="/" className="btn-primary my-4 inline-block">Kembali ke Halaman Utama</Link>

    </div>
  )
}

export default NotFound