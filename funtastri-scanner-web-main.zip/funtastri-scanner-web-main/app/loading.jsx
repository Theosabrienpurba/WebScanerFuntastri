import Loader from "./components/Loader";

const Loading = () => {
  console.log("loading file is called");

  return (
    <div className="">
      <Loader transparentMode="visible" />
    </div>
  )
}

export default Loading