import ScannerBtn from '../components/ScannerBtn';

const BoothHome = ({ params }) => {
  console.log(params.booth);

  const booths = [
    {
      slug: "check-in",
      title: "Check-In",
    },
    {
      slug: "fnb",
      title: "FnB",
    },
    {
      slug: "games",
      title: "Games",
    },
    {
      slug: "lucky-draw",
      title: "Lucky Draw",
    },
  ]

  const boothTitle = booths.filter((booth) => booth.slug === params.booth)[0].title;

  return (
    <div className="px-4 pt-8">
      <div className="mb-4">
        <h1 className="mb-4 w-full font-sans font-semibold">
          {boothTitle}
        </h1>
        <p className="w-full">
          Scan Code QR peserta
        </p>
      </div>

      <div className="mt-20">
        <ScannerBtn pageTarget={`/scan/${params.booth}/`} />
      </div>

    </div>
  )
}

export default BoothHome

export async function generateStaticParams() {
  const booths = [
    "check-in",
    "fnb",
    "games",
    "lucky-draw",
  ]

  return booths.map((booth) => ({ booth: booth }));
}

// route segment config
export const dynamicParams = false;