'use client'

import Header from './components/Layout/Header'
import './globals.css'

export default function GlobalError({ error, reset }) {
  return (
    <html>
      <body>
        <Header />
        <main className="container pt-8 px-8 flex justify-center items-center flex-col">
          <h2>Ada Kesalahan!</h2>
          <button className="btn-primary my-4" onClick={() => reset()}>Coba lagi</button>
        </main>
      </body>
    </html>
  )
}