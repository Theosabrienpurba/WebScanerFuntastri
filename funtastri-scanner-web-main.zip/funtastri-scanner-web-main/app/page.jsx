import Image from 'next/image'
import Link from 'next/link'
import ScannerBtn from './components/ScannerBtn'
// import { useState } from 'react'

export default function Home() {
  // const [isScannerOpen, setIsScannerOpen] = useState(false);

  return (
    <div className="px-4 pt-8">
      <div className="mb-4">
        <h1 className="mb-4 w-full font-sans font-semibold">
          Check-In Page
        </h1>
        <p className="w-full">
          Scan Code QR untuk Check-In
        </p>
      </div>

      <div className="mt-20">
        <ScannerBtn pageTarget="/scan/check-in/" />
      </div>

    </div>
  )
}
