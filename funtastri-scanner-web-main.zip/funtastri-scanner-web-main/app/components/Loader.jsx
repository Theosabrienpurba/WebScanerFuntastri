import React from 'react'

const Loader = ({ text = "", transparentMode = "transparent", customBgColor = "#FFEEF6", customOpacity = "75", ...props }) => {
  const transparentModeConfig = {
    transparent: "bg-transparent",
    half: `bg-opacity-50 bg-[${customBgColor}]`,
    custom: `bg-opacity-${customOpacity} bg-[${customBgColor}]`,
    visible: `bg-[${customBgColor}]`,
  }
  return (
    <div className={`absolute h-[calc(100vh_-_81px)] w-full transition duration-200`}>
      <div className={`absolute flex items-center justify-center left-0 top-0 w-full h-full z-[9] ${transparentModeConfig[transparentMode]}`}>
        <span className="loader -mt-[50%]" {...props}></span>
        <span className="absolute">{text}</span>
      </div>
    </div>
  )
}

export default Loader