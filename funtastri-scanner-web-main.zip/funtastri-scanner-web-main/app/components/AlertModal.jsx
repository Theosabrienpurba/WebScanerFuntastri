import parse from 'html-react-parser';
import { useEffect, useState } from 'react'
import Modal from 'react-responsive-modal'

const AlertModal = ({
  isOpen,
  onClose,
  onConfirm,
  icon,
  title,
  text,
  cancelButtonText,
  confirmButtonText,
  confirmButtonOnly,
  ...props
}) => {

  const [disableBtn, setDisableBtn] = useState(false);

  const confirmClicked = (ev) => {
    ev?.preventDefault();
    setDisableBtn(true);
    onConfirm(ev);
  }

  const closeClicked = (ev) => {
    ev?.preventDefault();
    setDisableBtn(true);
    onClose(ev);
  }

  useEffect(() => {
    isOpen && setDisableBtn(false)
  }, [isOpen])

  return (
    <div>
      {/* Modal */}
      <Modal
        open={isOpen}
        onClose={closeClicked}
        classNames={{
          modal: "rounded bg-[#FFEEF6] min-w-[300px]"
        }}
        modalId="alertModal"
        showCloseIcon={false}
        center={true}
        reserveScrollBarGap={true}
        {...props}
      >
        <div className="flex flex-col items-center justify-center py-4 px-4">
          <h2 className="font-bold text-[#FF007A] text-center text-2xl mb-4">
            {title ?? "Peringatan"}
          </h2>
          <div className="text-center text-[#FF007A]"
          // dangerouslySetInnerHTML={{
          //   __html: text ?? "Yakin untuk melanjutkan?"
          // }}
          >
            {text !== undefined || text !== null ? parse(text || "") : "Yakin untuk melanjutkan?"}
          </div>
          {
            confirmButtonOnly ? (
              <div className="flex items-center justify-center mt-8 w-full">
                <button
                  // className="kembali border-2 inline-block px-4 py-3 text-white font-semibold text-center tracking-tight justify-end bg-[#FF007A] hover:bg-[#FF007A] rounded-lg focus:ring-4  transition duration-200"
                  className="btn-primary"
                  onClick={() => { confirmClicked() }}
                  {...disableBtn ? { "disabled": "disabled" } : ""}
                >
                  {confirmButtonText ?? "Tutup"}
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between mt-8 w-full">
                <button
                  // className="batal border-0 px-3 py-3 mr-12 text-[#f8419a] hover:text-white font-semibold text-center tracking-tight  hover:bg-red-600 rounded-lg focus:ring-4 transition duration-200"
                  className="btn-primary-outline"
                  onClick={() => { closeClicked() }}
                  {...disableBtn ? { "disabled": "disabled" } : ""}
                >
                  {cancelButtonText ?? "Batal"}
                </button>
                <button
                  // className="kembali border-2 inline-block px-4 py-3 text-white font-semibold text-center tracking-tight justify-end bg-[#FF007A] hover:bg-[#FF007A] rounded-lg focus:ring-4  transition duration-200"
                  className="btn-primary"
                  onClick={() => { confirmClicked() }}
                  {...disableBtn ? { "disabled": "disabled" } : ""}
                >
                  {confirmButtonText ?? "Ya"}
                </button>
              </div>
            )
          }

        </div>
      </Modal >
    </div >
  )
}

export default AlertModal
