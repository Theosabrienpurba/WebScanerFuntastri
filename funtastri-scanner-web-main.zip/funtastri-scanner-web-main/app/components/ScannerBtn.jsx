"use client"

import Image from "next/image"
import Link from "next/link"

const ScannerBtn = ({ pageTarget }) => {

  return (
    <div className="flex justify-center items-center">
      <Link
        // type="button"
        className="block rounded-lg shadow-lg hover:shadow-2xl focus:shadow-md"
        // onClick={() => { openScanner() }}
        href={pageTarget}
      >
        <Image src="/images/barcode.png" alt="Foto profil" width={187} height={187} />
      </Link>
    </div>
  )
}

export default ScannerBtn