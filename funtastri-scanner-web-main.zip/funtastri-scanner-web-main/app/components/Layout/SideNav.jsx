import Link from "next/link";

const SideNav = ({ navMenu, currentPathname, isSideNavOpen }) => {
  return (
    <div
      className={`${isSideNavOpen ? "left-0" : "-left-full"} transition-all duration-300 absolute w-full h-[calc(100vh_-_81px)] bg-[#F6DEEA] py-6 z-50`}
      style={{ zIndex: isSideNavOpen ? 50 : -1 }}
    >
      <div className="">
        <div className="w-full">
          <ul className="flex flex-col justify-center items-center">
            {navMenu.map((nav, idx) => {
              return (
                <li key={idx}>
                  <Link
                    href={nav.slug}
                    className={`${currentPathname === nav.slug ? "font-semibold bg-[#FF007A] text-white" : "font-medium text-[#FF007A]"} tracking-tight inline-block px-5 py-3 text-center hover:bg-pink-500 hover:text-white rounded-full my-3 focus:ring-4 focus:ring-pink-400 transition duration-200`}
                  >
                    {nav.title}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SideNav;
