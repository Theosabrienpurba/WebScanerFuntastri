"use client"

import Image from 'next/image'
import Link from 'next/link'
import React, { useEffect, useState } from 'react'
import { usePathname, useSearchParams } from "next/navigation"
import SideNav from './SideNav'
import funtastriLogo from "../../../public/images/logo.png"
import ProgressBar from 'next-nprogress-bar'

const navMenu = [
  {
    slug: "/",
    title: "Check-In",
  },
  {
    slug: "/fnb/",
    title: "Booth FnB",
  },
  {
    slug: "/games/",
    title: "Booth Games",
  },
  {
    slug: "/lucky-draw/",
    title: "Booth Lucky Draw",
  },
]

const Header = () => {
  const currentPathname = usePathname();
  const searchParams = useSearchParams();

  const [isSideNavOpen, setIsSideNavOpen] = useState(false)

  const openSideNav = () => {
    setIsSideNavOpen(!isSideNavOpen);
  }

  useEffect(() => {
    setIsSideNavOpen(false);
  }, [currentPathname, searchParams])

  return (
    <>
      <ProgressBar
        height="4px"
        color="#FF007A"
        options={{ showSpinner: true }}
        appDirectory={true}
      />

      <header className="relative">
        <div className="bg-white border-b border-[#FF007A]">
          <div className="container px-4 mx-auto">
            <div className="flex items-center justify-between">

              <div className="w-32 h-20">
                <div href="#" className="relative h-full">
                  <Image
                    src={funtastriLogo}
                    alt="Funtastri"
                    sizes="128px"
                    fill
                    className="object-cover"
                    placeholder="blur"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center">
                <div className="hidden lg:block">
                  <ul className="flex items-center mr-8">
                    {navMenu.map((nav, idx) => {
                      return (
                        <li key={idx}>
                          <Link href={nav.slug} className={`${currentPathname === nav.slug ? "font-semibold bg-[#FF007A] text-white" : "font-medium text-[#FF007A]"} mr-14 tracking-tight inline-block px-5 py-3 text-center hover:bg-pink-500 hover:text-white rounded-lg focus:ring-4 focus:ring-pink-400 transition duration-200`}>
                            {nav.title}
                          </Link>
                        </li>
                      )
                    })}
                  </ul>
                </div>
              </div>

              <div>
                <button
                  type="button"
                  onClick={() => { openSideNav() }}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-9 h-9 text-[#FF007A]">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                  </svg>

                </button>
              </div>

            </div>
          </div>

        </div>

        <SideNav
          navMenu={navMenu}
          currentPathname={currentPathname}
          isSideNavOpen={isSideNavOpen}
        />

      </header>
    </>
  )
}

export default Header