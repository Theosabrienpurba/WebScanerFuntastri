"use client";

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import QrScanner from 'qr-scanner';
import { useEffect, useState } from 'react';
import CryptoJS from 'crypto-js';
import AlertModal from './AlertModal';

const Scanner = ({ setScanResult, scanTarget }) => {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const router = useRouter();

  const [openErrorModal, setOpenErrorModal] = useState(false);
  const [errorModalTitle, setErrorModalTitle] = useState("");

  const errorModalClose = () => {
    setOpenErrorModal(false);
    router.push(`/${scanTarget !== "check-in" ? scanTarget : ""}`);
  }

  useEffect(() => {
    router.prefetch(`/result/${scanTarget}/`);
    const videoElem = document.getElementById("scanner-video-elem");

    let qrScanner = new QrScanner(
      videoElem,
      (result) => {
        console.log('decoded qr code:', result);
        qrScanner.stop();
        qrScanner.destroy();
        qrScanner = null;

        try {
          const uniqueID = result.data;
          const decoded = CryptoJS.enc.Base64.parse(uniqueID).toString(CryptoJS.enc.Utf8);
          const data = JSON.parse(CryptoJS.AES.decrypt(decoded, process.env.NEXT_PUBLIC_ENC_SECRET_KEY).toString(CryptoJS.enc.Utf8));
          console.log("success");
          window.localStorage.setItem("currentScannedUser", JSON.stringify(data));
          // setScanResult(data);
          router.push(`/result/${scanTarget}/`);
        } catch (error) {
          console.log("error: ", error);
          setOpenErrorModal(true);
          setErrorModalTitle("Kode QR Salah atau Invalid, Mohon coba lagi");
        }
      },
      {
        returnDetailedScanResult: true,
        preferredCamera: "environment",
        highlightScanRegion: true,
        highlightCodeOutline: true,
      },
    );

    (async () => {
      await qrScanner.start();
    })().then(() => {

    })

    return () => {
      if (qrScanner) {
        qrScanner.stop();
        qrScanner.destroy();
        qrScanner = null;
      }
    }
  }, [pathname, searchParams])

  /*
#scanner-container .scan-region-highlight {
      border-radius: 30px;
      outline: rgba(0, 0, 0, .25) solid 50vmax;
    }

    #scanner-container .scan-region-highlight-svg {
      display: none;
    }

    #scanner-container .code-outline-highlight {
      stroke: rgba(255, 255, 255, .5) !important;
      stroke-width: 15 !important;
      stroke-dasharray: none !important;
    }
  */

  return (
    <div className="scanner-wrapper relative flex items-center justify-center w-full h-[calc(100vh_-_81px)] overflow-hidden">
      <div className="scanner-container h-full">
        <video id="scanner-video-elem" className="w-full h-full object-cover object-center bg-[#FF007A]">
        </video>
      </div>
      <div className="absolute top-0 left-0 ml-4">
        <button className="bg-[#FF007A] text-white py-2 px-3">
          {/* <CrossButton /> */}x
        </button>
      </div>
      <div className="absolute bottom-0 right-0 mr-4 flex justify-center items-center">
        <button className="bg-[#FF007A] text-white py-2 px-3 mr-4">
          {/* <FlashButton isOn={isFlashOn} /> */}-
        </button>
        <button className="bg-[#FF007A] text-white py-2 px-3">
          {/* <CamChangeButton /> */}+
        </button>
      </div>
      <AlertModal
        isOpen={openErrorModal}
        onClose={errorModalClose}
        onConfirm={errorModalClose}
        title={errorModalTitle}
        text={""}
        confirmButtonOnly={true}
        confirmButtonText={"Tutup"}
      />
    </div>
  )
}

export default Scanner