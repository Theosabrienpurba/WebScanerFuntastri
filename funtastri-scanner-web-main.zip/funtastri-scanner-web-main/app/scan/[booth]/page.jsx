
import Scanner from '@/app/components/Scanner';
// import React, { useState } from 'react'

const BoothScanner = ({ params }) => {
  console.log(params.booth);
  // const [scanResult, setScanResult] = useState(null);

  return (
    <div>
      <Scanner
        // setScanResult={setScanResult}
        scanTarget={params.booth}
      />
    </div>
  )
}

export default BoothScanner

export async function generateStaticParams() {
  const booths = [
    "check-in",
    "fnb",
    "games",
    "lucky-draw",
  ]

  return booths.map((booth) => ({ booth: booth }));
}