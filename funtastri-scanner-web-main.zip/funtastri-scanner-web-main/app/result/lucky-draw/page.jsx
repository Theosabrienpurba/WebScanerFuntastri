"use client"

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react"
import "animate.css";
import axios from "axios";
import AlertModal from "@/app/components/AlertModal";
import Loader from "@/app/components/Loader";
import Link from "next/link";

const LuckyDraw = () => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [prizesData, setPrizesData] = useState(null);

  const [participantData, setParticipantData] = useState(null);
  const [selectedQuote, setSelectedQuote] = useState(0);

  const [selectedPrize, setSelectedPrize] = useState(0);

  const [isLoading, setIsLoading] = useState(true);

  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [confirmModalText, setConfirmModalText] = useState(false);

  const [openResultModal, setOpenResultModal] = useState(false);
  const [resultModalTitle, setResultModalTitle] = useState("");
  const [resultModalText, setResultModalText] = useState("");
  const [isResultSuccess, setIsResultSuccess] = useState(false);

  const [openErrorModal, setOpenErrorModal] = useState(false);
  const [errorModalTitle, setErrorModalTitle] = useState("");
  const [errorModalText, setErrorModalText] = useState("");

  const [luckyDrawConfirming, setLuckyDrawConfirming] = useState(false);

  const preventHistoryBackward = () => {
    const modalElem = document.getElementById("alertModal");
    modalElem.style.removeProperty("animation");
    modalElem.classList.add("animate__animated", "animate__headShake");

    setTimeout(() => {
      modalElem.classList.remove("animate__animated", "animate__headShake");
    }, 1000);

    window.history.pushState(null, null, "#confirm-modal");
  }

  const openConfirmModal = (luckyDrawPrize) => {
    window.history.pushState(null, null, "#confirm-modal");
    window.addEventListener("popstate", preventHistoryBackward)
    setSelectedPrize(luckyDrawPrize);
    setIsConfirmModalOpen(true);
    setConfirmModalText(`Berikan hadiah: ${luckyDrawPrize.prizeName}?`);
  };

  const closeConfirmModal = () => {
    if (window.location.hash.length > 0) {
      window.history.replaceState(null, null, window.location.pathname);
      window.removeEventListener("popstate", preventHistoryBackward);
    }
    setIsConfirmModalOpen(false);
  };

  const confirmLuckyDraw = async () => {
    console.log("confirming lucky draw...");
    setLuckyDrawConfirming(true);
    const updateParticipantQuote = axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/participant/${participantData.retailerID}`, {
      booth: "luckyDraw",
      prize: {
        prizeKey: selectedPrize.prizeKey,
        prizeName: selectedPrize.prizeName,
      }
    }, {
      headers: {
        Authorization: `Bearer ${process.env.NEXT_PUBLIC_API_TOKEN}`
      }
    })
      .then((response) => {
        console.log("success");
        console.log(response.data);
      })
      .catch((err) => {
        console.log(err)
        console.log(err.message)
      })

    // set stock
    const updatePrizeStock = axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/prize/update/luckyDraw`, {
      prizeKey: selectedPrize.prizeKey,
      prizeName: selectedPrize.prizeName,
      participantID: participantData.id || participantData._id,
    }, {
      headers: {
        Authorization: `Bearer ${process.env.NEXT_PUBLIC_API_TOKEN}`
      }
    })
      .then((response) => {
        console.log("success");
        console.log(response.data);
      });

    Promise.all([
      updateParticipantQuote,
      updatePrizeStock,
    ]).then((response) => {

      closeConfirmModal();

      console.log("success");
      console.log(response.data);
      closeConfirmModal();
      setIsResultSuccess(true);
      setResultModalTitle("Berhasil");
      setResultModalText(`Hadiah Diberi: ${selectedPrize.prizeName}`);
      setOpenResultModal(true);
    }).catch((error) => {
      console.error(error);
      console.error(error.message);
      // alert("Error: " + error.message)
      closeConfirmModal();
      setIsResultSuccess(false);
      setResultModalTitle("Ada Kesalahan, Mohon Coba Lagi");
      setOpenResultModal(true);
      setLuckyDrawConfirming(false);
    })
  }

  const closeResultModal = () => {
    if (isResultSuccess) {
      setOpenResultModal(false);
      router.push("/lucky-draw");
    } else {
      setOpenResultModal(false);
    }
  }

  const closeErrorModal = () => {
    setOpenErrorModal(false);
    router.push("/lucky-draw");
  }

  useEffect(() => {
    const currentData = JSON.parse(window.localStorage.getItem("currentScannedUser"));
    console.log("currentData: ", currentData);

    // get remaining quote
    setIsLoading(true);
    const getParticipantData = axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/participant/${currentData.retailerID}`).then((response) => {
      if (response.data.data.quote?.checkIn?.exchanged && response.data.data.quote.checkIn.exchanged > 0) {
        console.log(response.data.data);
        const remainingQuote = response.data.data.quote.luckyDraw.remaining;
        setParticipantData({ ...currentData, ...response.data.data, remainingQuote } || null);
        console.log(remainingQuote)
        setIsLoading(false);
      } else {
        setOpenErrorModal(true);
        setErrorModalTitle("Anda belum melakukan Check In");
        setErrorModalText(`
          <p className="text-opacity-80 mb-1">
            ${response.data.data?.outletName}
          </p>
          <h3 className="font-semibold mb-1">
            ${response.data.data?.ownerName}
          </h3>
          <p className="text-opacity-80 mb-1">
            ID: ${response.data.data?.retailerID}
          </p>
          <p className="text-opacity-80">
            Branch ${response.data.data?.branch}
          </p>
        `)
        setIsLoading(false);
      }
    }).catch((err) => {
      console.log(err);
      setOpenErrorModal(true);
      setErrorModalTitle("Ada Kesalahan, Mohon Coba Lagi");
      setIsLoading(false);
    })

    const getPrizesData = axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/prize?prizeTarget=Lucky%20Draw`).then((response) => {
      const prizes = response.data.data;
      setPrizesData(prizes || null);
    }).catch((err) => {
      console.log(err);
      setOpenErrorModal(true);
      setErrorModalTitle("Ada Kesalahan, Mohon Coba Lagi");
    })

    Promise.all([
      getParticipantData,
      getPrizesData,
    ]).then(() => {
      setIsLoading(false);
    })


    return () => {
      window.removeEventListener("popstate", preventHistoryBackward);
    }
  }, [])


  return (
    <div className="relative">
      {
        isLoading && (
          <div className={`${isLoading ? "opacity-100 visible" : "opacity-0 invisible"}`}>
            <Loader transparentMode="visible" text="Mengambil Data" />
          </div>
        )
      }
      <div className={`px-8 pt-8 transition duration-200`}>
        <nav className="text-sm mb-4" >
          <ul className="flex">
            <li>
              <Link href="/luckyDraw" className="text-primary transition duration-150 ease-in-out hover:text-primary-600 focus:text-primary-600 active:text-primary-700 dark:text-primary-400 dark:hover:text-primary-500 dark:focus:text-primary-500 dark:active:text-primary-600">
                Lucky Draw Scanner
              </Link>
            </li>
            <li>
              <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
            </li>
            <li className="text-[#FF007A]">Konfirmasi</li>
          </ul>
        </nav>
        <p className="text-opacity-80 mb-1">
          {participantData?.outletName}
        </p>
        <h3 className="text-xl font-semibold mb-1">
          {participantData?.ownerName}
        </h3>
        <p className="text-opacity-80 mb-1">
          ID: {participantData?.retailerID}
        </p>
        <p className="text-opacity-80 mb-4">
          Branch {participantData?.branch}
        </p>
        {participantData?.remainingQuote === 0 ? (
          <>
            <p className="mb-2">
              Mohon Maaf~
            </p>
            <p className="mb-4">
              {/* {participantData.quote.luckyDraw.quote} */}
              Kuota yang Anda miliki sudah digunakan!
            </p>
            <p className="mb-2">
              Anda sudah mendapatkan:
            </p>
            <p className="font-semibold mb-4">
              {participantData?.quote?.luckyDraw?.exchangeHistory?.[participantData?.quote?.luckyDraw?.exchangeHistory?.length - 1]?.name}
            </p>
          </>
        ) : (
          <>
            <>
              <p className="mt-6">
                Anda punya {participantData?.remainingQuote} kouta untuk bermain Lucky Draw
              </p>
              <div className="flex justify-center items-center flex-col">
                {!isLoading && prizesData && prizesData.map((prize, idx) => {
                  return (
                    <li key={idx} className="w-full list-none">
                      {prize.currentStock === 0 ? (
                        <div className="disabled btn-primary my-4 flex flex-col justify-center items-center">
                          <p className="font-semibold text-lg">
                            {prize.prizeName}
                          </p>
                          <div className="flex items-center justify-center">
                            <p className="text-sm text-opacity-60 mr-2">
                              Barang Habis
                            </p>
                          </div>
                        </div>
                      ) : (
                        <button type="button" onClick={() => { openConfirmModal(prize) }} className="btn-primary w-full my-4 flex flex-col justify-center items-center">
                          <p className="font-semibold text-lg">
                            {prize.prizeName}
                          </p>
                          <div className="flex items-center justify-center">
                            <p className="text-sm text-opacity-60 mr-2">
                              Sisa Barang
                            </p>
                            <p className="">
                              {prize.currentStock}
                            </p>
                          </div>
                        </button>
                      )}
                    </li>
                  )
                })}
              </div>

            </>
            {/* <p className="mt-6">
              Anda punya {participantData?.remainingQuote} kouta untuk bermain Lucky Draw
            </p>
            <div className="">
              <button
                className="btn-primary w-full py-5 disabled:bg-opacity-50 mt-28"
                onClick={() => { openConfirmModal() }}
                {...participantData?.remainingQuote === 0 ? { "disabled": "disabled" } : ""}
              >
                Konfirmasi
              </button>
            </div> */}
          </>

        )}

        {/* Modal */}
        <AlertModal
          isOpen={isConfirmModalOpen}
          onClose={closeConfirmModal}
          onConfirm={confirmLuckyDraw}
          title={"Konfirmasi hadiah Lucky Draw"}
          text={confirmModalText}
          confirmButtonText={"Lanjutkan"}
        />

        <AlertModal
          isOpen={openResultModal}
          onClose={closeResultModal}
          onConfirm={closeResultModal}
          title={resultModalTitle}
          text={resultModalText}
          confirmButtonOnly={true}
          closeOnOverlayClick={false}
        // confirmButtonText={"Tutup"}
        />

        <AlertModal
          isOpen={openErrorModal}
          onClose={closeErrorModal}
          onConfirm={closeErrorModal}
          title={errorModalTitle}
          text={errorModalText}
          confirmButtonOnly={true}
          closeOnOverlayClick={false}
        // confirmButtonText={"Tutup"}
        />
      </div>

    </div>
  )
}

export default LuckyDraw