"use client"

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react"
import "animate.css";
import axios from "axios";
import AlertModal from "@/app/components/AlertModal";
import Loader from "@/app/components/Loader";
import Link from "next/link";

const FnBResult = ({ params }) => {
  const { key } = params;

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [participantData, setParticipantData] = useState(null);
  const [selectedQuote, setSelectedQuote] = useState(0);

  const [isLoading, setIsLoading] = useState(true);

  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

  const [openResultModal, setOpenResultModal] = useState(false);
  const [resultModalTitle, setResultModalTitle] = useState("");
  const [resultModalText, setResultModalText] = useState("");
  const [isResultSuccess, setIsResultSuccess] = useState(false);

  const [openErrorModal, setOpenErrorModal] = useState(false);
  const [errorModalTitle, setErrorModalTitle] = useState("");

  const [checkingIn, setCheckingIn] = useState(false);

  const preventHistoryBackward = () => {
    const modalElem = document.getElementById("alertModal");
    modalElem.style.removeProperty("animation");
    modalElem.classList.add("animate__animated", "animate__headShake");

    setTimeout(() => {
      modalElem.classList.remove("animate__animated", "animate__headShake");
    }, 1000);

    window.history.pushState(null, null, "#confirm-modal");
  }

  const openConfirmModal = () => {
    window.history.pushState(null, null, "#confirm-modal");
    window.addEventListener("popstate", preventHistoryBackward)
    setIsConfirmModalOpen(true);
  };

  const closeConfirmModal = () => {
    if (window.location.hash.length > 0) {
      window.history.replaceState(null, null, window.location.pathname);
      window.removeEventListener("popstate", preventHistoryBackward);
    }
    setIsConfirmModalOpen(false);
  };

  const confirmFnB = async () => {
    try {
      console.log("doing check-in...");
      setCheckingIn(true);
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/api/participant/${participantData.retailerID}`, {
        booth: "fnb",
        key: key,
        exchangeAmount: selectedQuote,
      }, {
        headers: {
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_API_TOKEN}`
        }
      });

      closeConfirmModal();

      console.log("success");
      console.log(response.data.data);
      closeConfirmModal();
      setIsResultSuccess(true);
      setResultModalTitle("Berhasil");
      setResultModalText(`Item ditukar: ${selectedQuote} ${participantData.quote.fnb[key].name}`);
      setOpenResultModal(true);
    } catch (error) {
      console.error(error);
      console.error(error.message);
      // alert("Error: " + error.message)
      closeConfirmModal();
      setIsResultSuccess(false);
      setResultModalTitle("Ada Kesalahan, Mohon Coba Lagi");
      setOpenResultModal(true);
    }
    setCheckingIn(false);
  }

  const closeResultModal = () => {
    if (isResultSuccess) {
      setOpenResultModal(false);
      router.push("/fnb");
    } else {
      setOpenResultModal(false);
    }
  }

  const closeErrorModal = () => {
    setOpenErrorModal(false);
    router.push("/fnb");
  }

  useEffect(() => {
    const currentPData = JSON.parse(window.localStorage.getItem("currentParticipantData"));
    console.log("currentPData: ", currentPData);
    setParticipantData({ ...currentPData } || null);
    setIsLoading(false);

    return () => {
      if (window.location.hash.length > 0) {
        window.removeEventListener("popstate", preventHistoryBackward);
      }
    }
  }, [])


  return (
    <div className="relative">
      {
        isLoading && (
          <div className={`${isLoading ? "opacity-100 visible" : "opacity-0 invisible"}`}>
            <Loader transparentMode="visible" text="Mengambil Data" />
          </div>
        )
      }
      <div className={`px-8 pt-8 transition duration-200`}>
        <nav className="text-sm mb-4" >
          <ul className="flex">
            <li>
              <Link href="/fnb" className="text-primary transition duration-150 ease-in-out hover:text-primary-600 focus:text-primary-600 active:text-primary-700 dark:text-primary-400 dark:hover:text-primary-500 dark:focus:text-primary-500 dark:active:text-primary-600">
                FnB Scanner
              </Link>
            </li>
            <li>
              <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
            </li>
            <li>
              <Link href="/result/fnb" className="text-[#FF007A]">
                Pilih Item
              </Link>
            </li>
            <li>
              <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
            </li>
            <li className="text-[#FF007A]">
              Pilih Kuota
            </li>
          </ul>
        </nav>
        <p className="text-opacity-80 mb-1">
          {participantData?.outletName}
        </p>
        <h3 className="text-xl font-semibold mb-1">
          {participantData?.ownerName}
        </h3>
        <p className="text-opacity-80 mb-4">
          ID: {participantData?.retailerID}
        </p>
        {!isLoading && participantData?.quote.fnb[key].remaining > 0 && (
          <>
            {/* <p className="mb-4">
              Total kuota Anda: {participantData?.quote.fnb[key].quote} {participantData?.quote.fnb[key].name}
            </p> */}
            <p className="mb-4">
              Sisa kuota saat ini: {participantData?.quote.fnb[key].remaining} {participantData?.quote.fnb[key].name}
            </p>
          </>
        )}
        {!isLoading && participantData?.quote.fnb[key].remaining === 0 && (
          <>
            <p className="mb-2">
              Mohon Maaf~
            </p>
            <p className="mb-4">
              {participantData?.quote.fnb[key].quote} Kuota yang Anda miliki sudah digunakan!
            </p>
          </>
        )}
        <div className={`border-y border-[#FF007A] my-6 flex justify-between items-center py-5 ${participantData?.quote.fnb[key].remaining == 0 ? "opacity-75" : ""}`}>
          <p className="">
            Tentukan Jumlah Kuota {participantData?.quote.fnb[key].name} yang diambil
          </p>

          <div className="relative flex rounded-full bg-[#FFEEF6] px-2 py-2">
            <button
              className="py-1 px-2 text-[#FFEEF6] bg-[#FF007A] hover:bg-opacity-80 rounded-full w-8 h-8 disabled:bg-opacity-50"
              onClick={() => {
                if (selectedQuote > 0) {
                  setSelectedQuote(selectedQuote - 1)
                }
              }}
              {...!participantData || selectedQuote <= 0 ? { "disabled": "disabled" } : ""}
            >
              -
            </button>

            <input type="text" placeholder="0" value={selectedQuote} className="text-xl text-center w-10 bg-transparent" disabled />

            <button
              className="py-1 px-2 text-[#FFEEF6] bg-[#FF007A] hover:bg-opacity-80 rounded-full w-8 h-8 disabled:bg-opacity-50"
              onClick={() => {
                if (selectedQuote < participantData?.quote.fnb[key].remaining) {
                  setSelectedQuote(selectedQuote + 1)
                }
              }}
              {...!participantData || selectedQuote >= participantData?.quote.fnb[key].remaining ? { "disabled": "disabled" } : ""}
            >
              +
            </button>

            <div>

            </div>
          </div>

        </div>

        <div className="">
          <button
            className="btn-primary w-full py-5 disabled:bg-opacity-50"
            onClick={() => { openConfirmModal() }}
            {...selectedQuote === 0 ? { "disabled": "disabled" } : ""}
          >
            Konfirmasi
          </button>
        </div>

        {/* Modal */}
        <AlertModal
          isOpen={isConfirmModalOpen}
          onClose={closeConfirmModal}
          onConfirm={confirmFnB}
          title={`Konfirmasi Penukaran `}
          text={`Menukarkan ${selectedQuote} ${participantData?.quote.fnb[key].name}`}
          confirmButtonText={"Lanjutkan"}
        />

        <AlertModal
          isOpen={openResultModal}
          onClose={closeResultModal}
          onConfirm={closeResultModal}
          title={resultModalTitle}
          text={resultModalText}
          confirmButtonOnly={true}
          closeOnOverlayClick={false}
        // confirmButtonText={"Tutup"}
        />

        <AlertModal
          isOpen={openErrorModal}
          onClose={closeErrorModal}
          onConfirm={closeErrorModal}
          title={errorModalTitle}
          text={""}
          confirmButtonOnly={true}
          closeOnOverlayClick={false}
        // confirmButtonText={"Tutup"}
        />
      </div>

    </div>
  )
}

export default FnBResult