"use client"

import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react"
import "animate.css";
import axios from "axios";
import AlertModal from "@/app/components/AlertModal";
import Link from "next/link";

const snacks = [
  {
    productName: "Snack Kotak",
    imageURL: "https://partojambe.com/asset/foto_produk/WhatsApp_Image_2023-03-14_at_15_32_01.jpeg",
    currentStock: 375,
    exchanged: 5,
    initialStock: 375
  },
  {
    productName: "Snack Anak",
    imageURL: "https://www.static-src.com/wcsstore/Indraprastha/images/catalog/full//88/MTA-43632042/oem_paket-snack-ulang-tahun-anak-hampers-anak-ulang-tahun_full01.jpg",
    currentStock: 375,
    exchanged: 5,
    initialStock: 375
  }
];

const Snack = () => {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [participantData, setParticipantData] = useState(null);
  const [selectedQuote, setSelectedQuote] = useState(
    snacks.map((snack) => ({
      productName: snack.productName,
      quantity: 0,
    }))
  );
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [checkingIn, setCheckingIn] = useState(false);

  const preventHistoryBackward = () => {
    const modalElem = document.getElementById("confirmModal");
    modalElem.style.removeProperty("animation");
    modalElem.classList.add("animate__animated", "animate__headShake");

    // modalElem.style.animation = "300ms ease 0s 1 normal none running react-responsive-modal-modal-in"
    setTimeout(() => {
      modalElem.classList.remove("animate__animated", "animate__headShake");
    }, 1000);

    window.history.pushState(null, null, "#confirm-modal");
  }

  const openModal = () => {
    window.history.pushState(null, null, "#confirm-modal");
    window.addEventListener("popstate", preventHistoryBackward)
    setIsModalOpen(true);
  };

  const closeModal = () => {
    window.history.replaceState(null, null, window.location.pathname);
    window.removeEventListener("popstate", preventHistoryBackward);
    setIsModalOpen(false);
  };

  const confirmCheckIn = async () => {
    try {
      console.log("doing check-in...");
      setCheckingIn(true);
      const response = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/check-in`, {
        phoneNumber: participantData.phoneNumber,
        exchangeAmount: selectedQuote,
      }, {
        headers: {
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_API_TOKEN}`
        }
      });

      closeModal();

      console.log("success");
      console.log(response.data.data);
    } catch (error) {
      console.error(error.message);
      alert("Error: " + error.message)
    }
    setCheckingIn(false);
  }

  useEffect(() => {
    const currentData = JSON.parse(window.localStorage.getItem("currentScannedUser"));
    console.log(currentData)

    setParticipantData(currentData || null);

    return () => {
      window.removeEventListener("popstate", preventHistoryBackward);
    }
  }, [])

  return (
    <div className="pt-8">
      <nav className="w-full rounded-md ml-6" style={{ fontSize: "13px" }}>
        <ol className="list-reset flex">
          <li>
            <Link href="/" className="text-primary transition duration-150 ease-in-out hover:text-primary-600 focus:text-primary-600 active:text-primary-700 dark:text-primary-400 dark:hover:text-primary-500 dark:focus:text-primary-500 dark:active:text-primary-600">
              Homepage
            </Link>
          </li>
          <li>
            <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
          </li>
          <li>
            <Link href="/result/fnb/" className="text-primary transition duration-150 ease-in-out hover:text-primary-600 focus:text-primary-600 active:text-primary-700 dark:text-primary-400 dark:hover:text-primary-500 dark:focus:text-primary-500 dark:active:text-primary-600">
              Booth FnB
            </Link>
          </li>
          <li>
            <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
          </li>
          <li className="text-[#FF007A]">Reward Makanan</li>
        </ol>
      </nav>
      <br></br>
      <br></br>
      <p className='flex w-full font-sans font-semibold text-[16px] ml-6'>
        {participantData?.ownerName}
      </p>
      <br></br>
      <p className='flex w-full font-sans text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl text-[16px] ml-6'>
        Saat ini Anda memiliki kuota untuk: {participantData?.maxQuote} Orang
      </p>
      <h1 class="text-[#FF007A] font-semibold ml-6 mt-6 mb-6 font-sans">Pilih Snacks</h1>      

      {/* snack */}

      <div className="flex flex-wrap items-center p-6">
        <div className="lg:block">
          <div className="grid grid-cols-2 gap-8">
            {snacks.map((snack, idx) => (
              <div
                key={idx}
                className="max-w-sm relative rounded overflow-hidden shadow-lg text-center rounded-lg border z-10"
                style={{ border: "3px solid #FFB3D7" }}
              >
                <div style={{ width: "100%", height: "100%", position: "relative", zIndex: 1 }} className="shadow-2xl rounded-lg">
                  <img 
                    className="p-2"
                    src={snack.imageURL}
                    alt={snack.productName}
                    style={{ objectFit: "cover", width: "250px", height: "150px",borderRadius:"30px" }}
                  />
                  <div className="rounded-lg"
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                      color: "black",
                      fontSize: "4vw",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      display: "-webkit-box",
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: "vertical",
                      boxShadow: "0 50px 100px #FFB3D780"
                    }}
                  >

                    <Link href="/menu"
                      className="order-button relative rounded-lg px-4 py-2.5 overflow-hidden group bg-pink-50 relative flex justify-center w-auto">
                      <span className="relative inline-block max-w-full">
                        {snack.productName}
                      </span>
                    </Link>
                  </div>
                  <div className='justify-end flex mr-7 mb-3 mt-1'>
                  <button
                    className="py-1 px-2 bg-pink-500 hover:bg-pink-400 rounded-l"
                    onClick={() => {
                      if (selectedQuote[idx].quantity > 0) {
                        const updatedSelectedQuote = [...selectedQuote];
                        updatedSelectedQuote[idx].quantity -= 1;
                        setSelectedQuote(updatedSelectedQuote);
                      }
                    }}
                    {...!participantData || selectedQuote[idx].quantity <= 0 ? { disabled: "disabled" } : ""}
                  >
                    -
                  </button>

                  <input
                    type="text"
                    placeholder="0"
                    value={selectedQuote[idx].quantity}
                    className="text-xl text-center w-10 bg-[#FFB3D7]"
                    disabled
                  />

                  <button
                    className="py-1 px-2 bg-pink-500 hover:bg-pink-400 rounded-r"
                    onClick={() => {
                      if (selectedQuote[idx].quantity < 3) {
                        const updatedSelectedQuote = [...selectedQuote];
                        updatedSelectedQuote[idx].quantity += 1;
                        setSelectedQuote(updatedSelectedQuote);
                      }
                    }}
                    {...!participantData || selectedQuote[idx].quantity >= 3 ? { disabled: "disabled" } : ""}
                  >
                    +
                  </button>

              <div>

              </div>
            </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* end */}
      <div className="flex justify-center">
  <div className="corm w-full mt-5 mb-10">
    <button
      className="w-full font-sans font-semibold text-[#FF007A]"
      onClick={() => { openModal() }}
      {...selectedQuote === 0 ? { disabled: "disabled" } : {}}
    >
      <div className="flex justify-between">
        <div className="text-left">
          <p style={{ whiteSpace: "nowrap", fontSize: "10px", maxWidth: "100%" }}>
            {selectedQuote.reduce((total, quote) => total + quote.quantity, 0) > 3
              ? "3+"
              : selectedQuote.reduce((total, quote) => total + quote.quantity, 0)}{" "}
            Kouta
          </p>
          <p
            style={{
              fontSize: "10px",
              maxWidth: "100%",
              maxHeight: "3em",
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
              whiteSpace: "normal",
              lineHeight: "1.1em", // Atur tinggi baris sesuai kebutuhan
            }}
            className=""
          >
            {selectedQuote
              .filter((quote) => quote.quantity > 0)
              .map((quote) => `${quote.productName} (${quote.quantity})`)
              .join(", ")}
          </p>
        </div>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="w-6 h-6"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"
          />
        </svg>
      </div>
    </button>
  </div>
      </div>
    </div>
  )
}

export default Snack