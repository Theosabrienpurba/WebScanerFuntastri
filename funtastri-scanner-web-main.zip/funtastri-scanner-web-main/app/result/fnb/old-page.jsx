"use client"

import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react"
import axios from "axios";
import Link from "next/link";

const Fnb = () => {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [participantData, setParticipantData] = useState(null);

  useEffect(() => {
    const currentData = JSON.parse(window.localStorage.getItem("currentScannedUser"));
    console.log(currentData)

    setParticipantData({ ...currentData } || null);

    // get remaining quote
    // setIsLoading(true);
    // axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/participant/${currentData.retailerID}`).then((response) => {
    //   const participant = response.data.data;
    //   setParticipantData({ ...currentData, remainingQuote } || null);
    //   console.log(remainingQuote)
    //   // setIsLoading(false);
    // }).catch((err) => {
    //   console.log(err);
    //   setOpenErrorModal(true);
    //   setErrorModalTitle("Ada Kesalahan, Mohon Coba Lagi");
    //   // setIsLoading(false);
    // })
    return () => {
    }
  }, [])

  return (
    <div className="px-8 pt-8">
      <nav className="text-sm mb-4" >
        <ul className="flex">
          <li>
            <Link href="/fnb" className="text-primary transition duration-150 ease-in-out hover:text-primary-600 focus:text-primary-600 active:text-primary-700 dark:text-primary-400 dark:hover:text-primary-500 dark:focus:text-primary-500 dark:active:text-primary-600">
              FnB Scanner
            </Link>
          </li>
          <li>
            <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
          </li>
          <li className="text-[#FF007A]">Booth FnB</li>
        </ul>
      </nav>
      <p className="font-semibold mb-4">
        {participantData?.ownerName}
      </p>
      {/* <p className="">
        Saat ini Anda memiliki kuota untuk:
      </p>
      <p className="">
        3 makanan, 3 snack & 3 minuman
      </p> */}
      <p className="mb-4">
        Pilih Jenis Item
      </p>
      <div className="flex justify-center items-center flex-col">
        <Link href="/result/fnb/food/" className="btn-primary inline-block w-full mb-8">
          Makanan
        </Link>
        <Link href="/result/fnb/beverage/" className="btn-primary inline-block w-full mb-8">
          Minuman
        </Link>
        <Link href="/result/fnb/snack/" className="btn-primary inline-block w-full mb-8">
          Snacks
        </Link>
      </div>
    </div>
  )
}

export default Fnb