"use client"

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react"
import axios from "axios";
import Link from "next/link";
import Loader from "@/app/components/Loader";
import AlertModal from "@/app/components/AlertModal";

const Fnb = () => {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [participantData, setParticipantData] = useState(null);

  const [isLoading, setIsLoading] = useState(true);

  const [openErrorModal, setOpenErrorModal] = useState(false);
  const [errorModalTitle, setErrorModalTitle] = useState("");
  const [errorModalText, setErrorModalText] = useState("");

  const closeErrorModal = () => {
    setOpenErrorModal(false);
    router.push("/fnb");
  }

  useEffect(() => {
    const currentData = JSON.parse(window.localStorage.getItem("currentScannedUser"));
    console.log(currentData)

    setParticipantData({ ...currentData } || null);

    // get remaining quote
    setIsLoading(true);
    axios.get(`${process.env.NEXT_PUBLIC_API_URL}/api/participant/${currentData.retailerID}`).then((response) => {
      console.log(response.data.data);
      setParticipantData({ ...currentData, ...response.data.data } || null);
      window.localStorage.setItem("currentParticipantData", JSON.stringify(response.data.data));
      setIsLoading(false);
      if (!response.data.data.quote?.checkIn?.exchanged || response.data.data.quote.checkIn.exchanged === 0) {
        console.log("quote: ", response.data.data.quote.checkIn?.exchanged);
        setOpenErrorModal(true);
        setErrorModalTitle("Anda belum melakukan Check In");
        setErrorModalText(`
          <p className="text-opacity-80 mb-1">
            ${response.data.data?.outletName}
          </p>
          <h3 className="font-semibold mb-1">
            ${response.data.data?.ownerName}
          </h3>
          <p className="text-opacity-80 mb-1">
            ID: ${response.data.data?.retailerID}
          </p>
          <p className="text-opacity-80">
            Branch ${response.data.data?.branch}
          </p>
        `);
        setIsLoading(false);
      }
    }).catch((err) => {
      console.log(err);
      setOpenErrorModal(true);
      setErrorModalTitle("Ada Kesalahan, Mohon Coba Lagi");
      setIsLoading(false);
    })
    return () => {
    }
  }, [])

  return (
    <div className="relative">
      {
        isLoading && (
          <div className={`${isLoading ? "opacity-100 visible" : "opacity-0 invisible"}`}>
            <Loader transparentMode="visible" text="Mengambil Data" />
          </div>
        )
      }
      <div className="px-8 pt-8">
        <nav className="text-sm mb-4" >
          <ul className="flex">
            <li>
              <Link href="/fnb" className="text-primary transition duration-150 ease-in-out hover:text-primary-600 focus:text-primary-600 active:text-primary-700 dark:text-primary-400 dark:hover:text-primary-500 dark:focus:text-primary-500 dark:active:text-primary-600">
                FnB Scanner
              </Link>
            </li>
            <li>
              <span className="mx-2 text-neutral-500 dark:text-neutral-400">/</span>
            </li>
            <li className="text-[#FF007A]">Pilih Item</li>
          </ul>
        </nav>
        <p className="text-opacity-80 mb-1">
          {participantData?.outletName}
        </p>
        <h3 className="text-xl font-semibold mb-1">
          {participantData?.ownerName}
        </h3>
        <p className="text-opacity-80 mb-2">
          ID: {participantData?.retailerID}
        </p>
        <p className="text-opacity-80 mb-2">
          Branch {participantData?.branch}
        </p>
        <p className="mb-4">
          Jumlah yang Check In: {participantData?.quote?.checkIn?.exchanged} orang
        </p>
        <p className="text-lg mb-4">
          Pilih Item
        </p>
        <div className="flex justify-center items-center flex-col">
          {!isLoading && Object.entries(participantData?.quote?.fnb).map(([key, val], idx) => {
            if (!key.startsWith("fnb")) {
              return <></>
            }
            return (
              <li key={idx} className="w-full list-none">
                {val.remaining === 0 ? (
                  <div className="disabled btn-primary my-4 flex flex-col justify-center items-center">
                    <p className="font-semibold text-lg">
                      {val.name}
                    </p>
                    <div className="flex items-center justify-center">
                      <p className="text-sm text-opacity-60 mr-2">
                        Sisa Kuota
                      </p>
                      <p className="">
                        {val.remaining}
                      </p>
                    </div>
                  </div>
                ) : (
                  <Link href={`/result/fnb/${key}`} className="btn-primary my-4 flex flex-col justify-center items-center">
                    <p className="font-semibold text-lg">
                      {val.name}
                    </p>
                    <div className="flex items-center justify-center">
                      <p className="text-sm text-opacity-60 mr-2">
                        Sisa Kuota
                      </p>
                      <p className="">
                        {val.remaining}
                      </p>
                    </div>
                  </Link>
                )}
              </li>
            )
          })}
        </div>
      </div>

      <AlertModal
        isOpen={openErrorModal}
        onClose={closeErrorModal}
        onConfirm={closeErrorModal}
        title={errorModalTitle}
        text={errorModalText}
        confirmButtonOnly={true}
        closeOnOverlayClick={false}
      // confirmButtonText={"Tutup"}
      />
    </div>
  )
}

export default Fnb